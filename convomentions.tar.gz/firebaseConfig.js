// ===================== FIREBASE CONFIG (placeholders) =====================
// 👉 Βάλε εδώ τα δικά σου στοιχεία από το Firebase Console

export const firebaseConfig = {
  apiKey: "AIzaSyAkK4Ao3crLIeYYBYoNMvUfIJftunr4JlU",
  authDomain: "convo-reignite.firebaseapp.com",
  databaseURL: "https://convo-reignite-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "convo-reignite",
  storageBucket: "convo-reignite.firebasestorage.app",
  messagingSenderId: "716144047787",
  appId: "1:716144047787:web:0a413e76917ea39250e9ee"
};
