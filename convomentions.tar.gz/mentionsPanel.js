// ===============================================================
// 💬 Convo Mentions Panel (mentionsPanel.js)
// ===============================================================

import { auth, db } from "./firebaseInit.js";
import { get } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-database.js";
import { ref, onValue } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-database.js";

// Προστασία από πολλαπλή αρχικοποίηση
if (window.__mentionsInit) {
  console.warn("⚠️ Mentions panel already initialized, skipping duplicate init.");
  return;
}
window.__mentionsInit = true;

let mentionsPopup = null;
let mentionsList = [];
let currentInput = null;

// ===============================================================
// 🧩 Init Mentions Panel
// ===============================================================
export function initMentionsPanel(inputEl) {
  if (window.__mentionsInit) return;
window.__mentionsInit = true;

  currentInput = inputEl;

  // Δημιουργία popup container (μία φορά)
  mentionsPopup = document.createElement("div");
  mentionsPopup.classList.add("mention-popup");
  mentionsPopup.style.display = "none";
  document.body.appendChild(mentionsPopup);
// το popup να είναι fixed για σωστή τοποθέτηση πάνω από τα panels
mentionsPopup.style.position = "fixed";
mentionsPopup.setAttribute("role", "listbox");

// κλείσιμο με ESC σε όλο το έγγραφο
document.addEventListener("keydown", handleEscClose);
  // Φόρτωση users από τη βάση (για @mentions)
  const usersRef = ref(db, "users");

  // Φόρτωση users μόνο μία φορά (όχι σε κάθε αλλαγή)


get(usersRef).then(snapshot => {
  mentionsList = [];
  snapshot.forEach(child => {
    const user = child.val();
    if (user.displayName) mentionsList.push(user.displayName);
  });
  console.log("📜 Mentions loaded:", mentionsList);
});


  // Listener για @input στο πεδίο
  inputEl.addEventListener("input", handleMentionInput);
  document.addEventListener("click", handleOutsideClick);
}

// ===============================================================
// 🔎 Handle Typing '@' + Search
// ===============================================================
function handleMentionInput(e) {
  const text = e.target.value;
  const cursorPos = e.target.selectionStart;
  const atIndex = text.lastIndexOf("@", cursorPos - 1);

  if (atIndex === -1) {
    hideMentions();
    return;
  }

  const query = text.slice(atIndex + 1, cursorPos).trim().toLowerCase();

  if (query.length === 0) {
    renderMentionsList(mentionsList);
  } else {
    const filtered = mentionsList.filter(u =>
      u.toLowerCase().startsWith(query)
    );
    renderMentionsList(filtered);
  }

  const rect = currentInput.getBoundingClientRect();
  mentionsPopup.style.left = `${rect.left + 60}px`;
  mentionsPopup.style.bottom = `${window.innerHeight - rect.top + 10}px`;
  mentionsPopup.style.display = "block";
}

// ===============================================================
// 🧾 Render Popup
// ===============================================================
function renderMentionsList(list) {
  if (!mentionsPopup) return;
  if (list.length === 0) {
    mentionsPopup.innerHTML = "<div class='mention-empty'>No matches</div>";
    return;
  }

  mentionsPopup.innerHTML = list
    .map(u => `<div class='mention-item'>${u}</div>`)
    .join("");

  mentionsPopup.querySelectorAll(".mention-item").forEach(item => {
    item.addEventListener("click", () => insertMention(item.textContent));
  });
}

// ===============================================================
// ✏️ Insert Selected Mention
// ===============================================================
function insertMention(name) {
  const text = currentInput.value;
  const cursorPos = currentInput.selectionStart;
  const atIndex = text.lastIndexOf("@", cursorPos - 1);

  if (atIndex === -1) return;

  const before = text.slice(0, atIndex);
  const after = text.slice(cursorPos);
  currentInput.value = `${before}@${name} ${after}`;
  hideMentions();
  currentInput.focus();
}

// ===============================================================
// 🧹 Hide Mentions Popup
// ===============================================================
function hideMentions() {
  if (mentionsPopup) mentionsPopup.style.display = "none";
}

// ===============================================================
// 🚫 Outside Click Handler
// ===============================================================
function handleOutsideClick(e) {
  if (mentionsPopup && !mentionsPopup.contains(e.target) && e.target !== currentInput) {
    hideMentions();
  }
}
// ===============================================================
// ⌨️ ESC Key Close Handler
// ===============================================================
function handleEscClose(e) {
  if (e.key === "Escape") {
    hideMentions();
  }
}
