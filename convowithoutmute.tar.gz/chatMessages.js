// ============================================================================
// 💬 CHAT MESSAGES — με υποστήριξη Rooms (Send + Receive)
// ============================================================================
import {
  ref,
  push,
  onChildAdded,
  onChildRemoved,
  serverTimestamp,
  remove,
  set,
  off,
  get
} from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";



import { auth, db } from "./firebaseInit.js";
import { setTypingState } from "./typing.js";
import { showConvoAlert, showConvoPrompt } from "./app.js";

// ============================================================================
// 🏠 Rooms System — Part B (Setup)
// ============================================================================
let currentRoom = "general";          // προεπιλεγμένο δωμάτιο
let messagesRef = null;               // active reference
let unsubscribe = null;               // για καθάρισμα listener

// === DOM Elements ===
const mainChat = document.getElementById("mainChat");
const messagesDiv = document.getElementById("messages");
const msgForm = document.getElementById("messageForm");
const msgInput = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");
const clearBtn = document.getElementById("clearChatBtn");
console.log("🧹 ClearChat button found:", !!clearBtn);

const adminMenu = document.getElementById("adminContextMenu");
let currentMsgEl = null;


// ============================================================================
// 📂 Φόρτωση μηνυμάτων για συγκεκριμένο room
// ============================================================================
export function loadRoomMessages(roomId) {
  // === Εντοπισμός του main chat ===
  const mainChat = document.getElementById("messages");
  if (!mainChat) {
    console.warn("⚠️ mainChat not found yet, retrying...");
    setTimeout(() => loadRoomMessages(roomId), 300);
    return;
  }

  // --- Καθαρισμός παλιού listener ---
  if (messagesRef) off(messagesRef); // σταματάει τον προηγούμενο

  // --- Νέο room ---
  currentRoom = roomId;
  messagesRef = ref(db, `v3/messages/${roomId}`);
  mainChat.innerHTML = `<p style="opacity:0.6;text-align:center;">📂 Loading ${roomId}...</p>`;
  

  // --- Φόρτωση νέων μηνυμάτων ---
  // --- Φόρτωση νέων μηνυμάτων (single source of truth) ---
onChildAdded(messagesRef, renderMessage);

// === Όταν ένα μήνυμα διαγραφεί (από admin ή clear) ===

onChildRemoved(messagesRef, (snap) => {
  const msgId = snap.key;
  const el = document.querySelector(`[data-id="${msgId}"]`);
  if (el) el.remove();

  // Αν δεν έμεινε κανένα μήνυμα, δείξε το "empty" hint
  if (!messagesDiv.querySelector(".message")) {
    messagesDiv.innerHTML = `<div class="empty-hint">👋 Καλωσήρθες! Στείλε το πρώτο σου μήνυμα.</div>`;
  }
});

  console.log(`✅ Now viewing room: ${roomId}`);
}


// ============================================================================
// ✉️ Αποστολή μηνύματος στο ενεργό room
// ============================================================================
sendBtn.addEventListener("click", async () => {
  const text = msgInput.value.trim();
  if (!text) return;
  if (!messagesRef) return;

  await push(messagesRef, {
    uid: auth.currentUser?.uid || "guest",
    username: auth.currentUser?.displayName || "Guest",
    text,
    createdAt: serverTimestamp(),
  });

  msgInput.value = "";
  msgInput.focus();
});
// ============================================================================
// 🔁 Room Change Event — Επικοινωνία με Rooms Panel
// ============================================================================
window.addEventListener("roomChanged", (e) => {
  const newRoom = e.detail.roomId;
  console.log("📦 Switching to room:", newRoom);
  
  loadRoomMessages(newRoom);
});

// === Αρχική φόρτωση default room ===
window.addEventListener("load", () => {
  // Ελέγχουμε ότι υπάρχει το mainChat πριν το χρησιμοποιήσουμε
  const mainChat = document.getElementById("mainChat");
  if (!mainChat) {
    console.warn("⚠️ mainChat not found in DOM yet.");
    return;
  }

  loadRoomMessages(currentRoom);
});



// === ENTER to send / SHIFT+ENTER for newline ===
if (msgInput && msgForm) {
  msgInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();         // μην κάνει newline
      msgForm.requestSubmit();    // στείλε το μήνυμα
    }
  });
}

// === Typing indicator updates ===
let typingTimeout;
msgInput.addEventListener("input", () => {
  setTypingState(true);
  clearTimeout(typingTimeout);
  typingTimeout = setTimeout(() => setTypingState(false), 1500);
});


// === SEND MESSAGE ===
if (msgForm) {
  msgForm.addEventListener("submit", async (e) => {
    e.preventDefault();
  const user = auth.currentUser;   // ✅ μετακινήθηκε εδώ
console.log("🟢 Message submit triggered");
  // === Ban Check (block banned users) ===
  if (user) {
    try {
      const userRef = ref(db, `users/${user.uid}/banned`);
      const snap = await get(userRef);
      const isBanned = snap.exists() && snap.val() === true;

      if (isBanned) {
        showConvoAlert("🚫 Έχεις αποκλειστεί από το chat.");
        msgInput.value = "";
        msgInput.blur();
        return; // ⛔ stop send
      }
    } catch (err) {
      console.error("Ban check error:", err);
    }
  }

    // === Block send for guests ===
// === Block send for guests (Read-Only Mode) ===
if (!user || user.isAnonymous) {
  // Μην επιτρέπεις αποστολή, αλλά χωρίς alert ή redirect
  const msgInput = document.getElementById("messageInput");
  if (msgInput) {
    msgInput.blur();
  }
  return; // ⛔ Stop message send
}



    const text = msgInput.value.trim();
    if (!text) return;

if (!user) return showConvoAlert("⚠️ Δεν είσαι συνδεδεμένος!");

    try {
      const msgRef = ref(db, `v3/messages/${currentRoom}`);
await push(msgRef, {

  uid: user.uid,
  username: user.displayName || "Guest",
  text,
  createdAt: serverTimestamp(),
});


      msgInput.value = "";
      msgInput.style.height = "40px"; // επαναφορά ύψους
    } catch (err) {
showConvoAlert("❌ Σφάλμα αποστολής: " + err.message);
    }
  });
}

// === RECEIVE MESSAGES (Realtime) ===
function renderMessage(data) {
  const msg = data.val();
  const el = document.createElement("div");
  el.classList.add("message");

  const name = msg.username || "Guest";
  const text = msg.text || "";
  const time = new Date(msg.createdAt || Date.now()).toLocaleTimeString("el-GR", {
    hour: "2-digit",
    minute: "2-digit",
  });

el.innerHTML = `
  <div class="msg-header">
    <span class="msg-user">${name}</span>
    <span class="msg-time">${time}</span>
  </div>
  <div class="msg-text">${text.replace(/\n/g, '<br>')}</div>
`;

  // === Σύνδεση UID Firebase ===
   el.dataset.id = data.key;
   el.dataset.uid = msg.uid || "";


  el.addEventListener("contextmenu", (e) => {
    if (!isAdmin()) return;
    e.preventDefault();
    currentMsgEl = el;

    adminMenu.style.top = e.clientY + "px";
    adminMenu.style.left = e.clientX + "px";
    adminMenu.classList.remove("hidden");
  });

  messagesDiv.appendChild(el);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

export function initMessagesListener(roomId = "general") {
  const msgRef = ref(db, `v3/messages/${roomId}`);
  onChildAdded(msgRef, renderMessage);
  console.log(`📡 Listening for messages in room: ${roomId}`);
}


// ============================================================================
// ADMIN — CLEAR CHAT (Step 1)
// ============================================================================
function isAdmin() {
  const u = auth.currentUser;
  if (!u) return false;
  const name = (u.displayName || "").toLowerCase();
  // προσωρινός κανόνας μέχρι το role persistence
  return name === "mysteryman" || name.includes("admin");
}

if (clearBtn) {
  clearBtn.addEventListener("click", async () => {
    if (!isAdmin()) { showConvoAlert("⛔ Μόνο για Admins."); return; }
const res = await showConvoPrompt(`🧹 Clear all messages για το room ‘${currentRoom}’; Αυτό δεν αναιρείται.`);
if (res !== "ok") return;


    try {
  if (!messagesRef) return;
  await remove(messagesRef);
  addAdminLog(`🧹 Cleared all messages in ${currentRoom}`);
} catch (err) {
  showConvoAlert("❌ Σφάλμα στο clear: " + err.message);
}

  });
}

// === Admin menu click ===
if (adminMenu) {
adminMenu.addEventListener("click", async (e) => {
  let action = e.target.closest("[data-action]")?.dataset.action;
console.log("🧩 Admin menu click:", action);

if (!currentMsgEl) return;

// ❌ βγάλε τη δεύτερη δήλωση — κρατάμε μόνο τη μία
// const action = e.target.dataset.action;  <-- σβήστο

    const msgId = currentMsgEl.dataset.id;
    if (!msgId || !action) return;

    adminMenu.classList.add("hidden");

    // === DELETE MESSAGE ===
    if (action === "delete") {
  const confirmDel = await showConvoPrompt("🗑️ Θες σίγουρα να διαγράψεις αυτό το μήνυμα;");
  if (confirmDel !== "ok") return;

  try {
    await remove(ref(db, `v3/messages/${currentRoom}/${msgId}`));
    addAdminLog(`🗑️ Deleted message in ${currentRoom}`);

    // ✅ Προσθέτουμε έλεγχο εδώ
    if (currentMsgEl) currentMsgEl.remove();

    showConvoAlert("✅ Το μήνυμα διαγράφηκε.");
  } catch (err) {
    console.error("❌ Delete error:", err);
    showConvoAlert("⚠️ Σφάλμα στη διαγραφή — δες κονσόλα.");
  } finally {
    currentMsgEl = null;
  }
}

    
  }); // ✅ Κλείνει το event listener του adminMenu
} // ✅ Κλείνει το if(adminMenu)
  


// ============================================================================
// ADMIN LOG — Helper Function
// ============================================================================
function addAdminLog(action) {
  const u = auth.currentUser;
  if (!u) return;
  const logRef = ref(db, "adminLogs");
  push(logRef, {
    action,
    by: u.displayName || "Unknown",
    timestamp: Date.now(),
  });
}

// === Κλείσιμο του menu όταν κάνεις click έξω ===
document.addEventListener("click", (e) => {
  if (!adminMenu.contains(e.target)) {
    setTimeout(() => {
      adminMenu.classList.add("hidden");
      currentMsgEl = null;
    }, 100); // 🕐 100ms delay so menu actions still register
  }
});
