// ============================================================================
// AUTH ACTIONS — Step 3 + Display Name Prompt Integration
// ============================================================================
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInAnonymously,
  signOut,
  updateProfile,
} from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";

import { ref, set } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";
import { auth, db } from "./firebaseInit.js";
import { showConvoPrompt, showConvoAlert } from "./app.js";

// === REGISTER (Step 1 – Display Name Prompt) ===
export async function registerUser() {
  const email = document.getElementById("registerEmail").value.trim();
  const password = document.getElementById("registerPassword").value.trim();

  if (!email || !password) {
    showConvoAlert("⚠️ Συμπλήρωσε όλα τα πεδία!");
    return;
  }

  try {
    // === Δημιουργία λογαριασμού ===
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // === Prompt για Display Name ===
    let displayName = "";
    while (!displayName) {
      const res = await showConvoPrompt(
        "🎭 Διάλεξε το display name που θα εμφανίζεται στο chat σου!\n(3–20 χαρακτήρες, λατινικά ή ελληνικά)"
      );
      if (!res || res.length < 3 || res.length > 20) {
        await showConvoAlert("⚠️ Το όνομα πρέπει να έχει 3–20 χαρακτήρες.");
      } else {
        displayName = res.trim();
      }
    }

    // === Ενημέρωση προφίλ στο Auth ===
    await updateProfile(user, { displayName });

    // === Αποθήκευση στη DB ===
    await set(ref(db, "users/" + user.uid), {
      displayName,
      role: "user",
      createdAt: Date.now(),
    });

    // === Επιβεβαίωση ===
    await showConvoAlert(`✨ Καλωσήρθες, ${displayName}!`);
    console.log("✅ Registered new user:", displayName);
  } catch (err) {
    showConvoAlert("❌ Σφάλμα εγγραφής: " + err.message);
  }
}

// === LOGIN ===
export async function loginUser() {
  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value;

  if (!email || !password) {
    showConvoAlert("⚠️ Συμπλήρωσε και τα δύο πεδία!");
    return;
  }

  try {
    await signInWithEmailAndPassword(auth, email, password);
    console.log("✅ Logged in:", email);
  } catch (err) {
    showConvoAlert("❌ Σφάλμα σύνδεσης: " + err.message);
  }
}

// === LOGIN AS GUEST ===
export async function loginGuest() {
  try {
    const userCredential = await signInAnonymously(auth);
    console.log("🟢 Guest login:", userCredential.user.uid);
  } catch (err) {
    showConvoAlert("❌ Guest login error: " + err.message);
  }
}

// === LOGOUT ===
export async function logoutUser() {
  try {
    await signOut(auth);
    console.log("🚪 Logged out");
  } catch (err) {
    showConvoAlert("❌ Logout error: " + err.message);
  }
}
