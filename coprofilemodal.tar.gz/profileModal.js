// ===============================================================
// 👤 Convo — profileModal.js (Step 4E)
// Purpose: Add role-based protection (only self-edit allowed)
// ===============================================================

import { auth, db } from "./firebaseInit.js";
import { currentUserData } from "./currentUser.js";
import { ref, update } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";
import { onValue, off } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";


const profileBtn = document.getElementById("profileBtn");
let modalOverlay;

export function initProfileModal() {
  if (!document.getElementById("profileModal")) {
    modalOverlay = document.createElement("div");
    modalOverlay.id = "profileModal";
    modalOverlay.className = "hidden modal-overlay";
    modalOverlay.innerHTML = `
      <div class="modal-box profile-box">
        <div class="modal-header">
          <h3>🧑 Profile</h3>
          <button id="closeProfileBtn" class="icon-btn">✖</button>
        </div>
        <div class="modal-content profile-content">
          <div class="profile-top">
            <div class="profile-avatar" id="profileAvatar"></div>
            <div class="profile-info">
              <div class="profile-name-row">
  <div class="profile-name" id="profileName">–</div>
</div>

              <div class="profile-role" id="profileRole">–</div>
              <div class="profile-status" id="profileStatus">–</div>
            </div>
          </div>

          <div class="profile-actions">
            <button id="changeAvatarBtn" class="btn small hidden">🖼️ Change Avatar</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modalOverlay);
  }

  // === Άνοιγμα modal ===
  profileBtn.addEventListener("click", () => {
    updateProfileUI();
    modalOverlay.classList.remove("hidden");
    document.body.classList.add("modal-open");
  });

  // === Κλείσιμο modal ===
  document.addEventListener("click", (e) => {
    if (e.target.id === "closeProfileBtn" || e.target.id === "profileModal") {
      modalOverlay.classList.add("hidden");
      document.body.classList.remove("modal-open");
    }
  });

// === Επεξεργασία avatar ===
document.addEventListener("click", async (e) => {
  if (e.target.id === "changeAvatarBtn") {
    const newURL = prompt("🖼️ Enter new avatar URL:", currentUserData.avatar || "");
    if (!newURL) return;
    const uid = auth.currentUser?.uid;
    if (!uid) return;

    await update(ref(db, "users/" + uid), { avatar: newURL });
    alert("✅ Avatar updated!");
  }
});

// === Εμφάνιση κουμπιού όταν συνδεθεί χρήστης ===
auth.onAuthStateChanged((user) => {
  if (user) profileBtn.classList.remove("hidden");
  else profileBtn.classList.add("hidden");
});

// === Update UI ===
function updateProfileUI() {
  const avatarBox = document.getElementById("profileAvatar");
  const nameEl = document.getElementById("profileName");
  const roleEl = document.getElementById("profileRole");
  const statusEl = document.getElementById("profileStatus");
  const avatarBtn = document.getElementById("changeAvatarBtn");

  if (!avatarBox || !nameEl) return;

  const name = currentUserData.displayName || "Unknown";
  const role = currentUserData.role || "user";
  const avatar = currentUserData.avatar;
  const online = currentUserData.online;
  const uid = auth.currentUser?.uid || "";
  const isSelf = uid === currentUserData.uid;

  // === Avatar ===
  if (avatar) {
    avatarBox.innerHTML = `<img src="${avatar}" alt="avatar" class="convo-avatar" />`;
  } else {
    const initials = name.charAt(0).toUpperCase();
    avatarBox.innerHTML = `<div class="convo-avatar-default">${initials}</div>`;
  }

  // === Info ===
  nameEl.textContent = name;
  roleEl.textContent = `Role: ${role}`;
  // === Real-time presence check from /status ===

const statusRef = ref(db, "status/" + uid);
onValue(statusRef, (snap) => {
  const state = snap.val()?.state;
  const isOnline = state === "online";
  statusEl.innerHTML = isOnline
    ? `<span class="dot online"></span> Online`
    : `<span class="dot offline"></span> Offline`;
});


  // === Ενεργοποίηση / απόκρυψη κουμπιού Avatar ===
  if (isSelf) avatarBtn.classList.remove("hidden");
  else avatarBtn.classList.add("hidden");
}}

// === Auto-init ===
initProfileModal();
