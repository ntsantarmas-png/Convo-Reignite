// ============================================================================
// Convo — Clean Base (No Rooms) — STEP 2
// Purpose: Firebase init + Auth State watcher
// ============================================================================
//  APP.JS — MAIN SCRIPT (Convo Clean Base)
//  All Firebase + Local Module Imports (merged and ordered)
// ============================================================================

// === Core Firebase ===
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";
import {
  ref,
  onChildAdded,
  onChildChanged,
  push,
  remove,
  serverTimestamp,
  update,
  onValue,
  get,
  set
} from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";
import { initYouTubePanel } from "./youtube.js";
import { updateProfile } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";


import { off } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";
let systemLogsActive = false;

// === Local Firebase Init ===
import { db, auth } from "./firebaseInit.js";

// === Auth & State Management ===
import { watchAuthState } from "./authState.js";
import { registerUser, loginUser, loginGuest, logoutUser } from "./authActions.js";

// === Core Chat Modules ===
import { initMessagesListener } from "./chatMessages.js";
import { setupPresence } from "./presence.js";
import { initUsersList } from "./usersList.js";
import { setTypingState, watchTyping } from "./typing.js";
import { initUsersPanel } from "./usersPanel.js";
import { initEmojiPanel } from "./emojiPanel.js";



// ============================================================================
// END OF IMPORTS — BEGIN APP LOGIC BELOW
// ============================================================================



console.log("🚀 Convo Step 2 loaded");

// === Start watching auth state ===
watchAuthState();
setupPresence();
initUsersList();
initUsersPanel();
initYouTubePanel();
// ===================== EMOJI PANEL INIT (Safe Load) =====================
let emojiPanelInitialized = false;

onAuthStateChanged(auth, (user) => {
  if (user && !emojiPanelInitialized) {
    initEmojiPanel();
    emojiPanelInitialized = true;
    console.log("😊 Emoji Panel initialized safely");
  }
});




// ===================== BASIC UI LOGIC (kept from Step 1) =====================

// ——— Auto-grow textarea (basic) ———
const msgInput = document.getElementById('messageInput');
if (msgInput){
  const base = 40, max = 140;
  msgInput.style.height = base + 'px';
  msgInput.addEventListener('input', () => {
    msgInput.style.height = base + 'px';
    msgInput.style.height = Math.min(msgInput.scrollHeight, max) + 'px';
  });
}


// ===================== AUTH BUTTON EVENTS =====================
document.getElementById("registerBtn")?.addEventListener("click", registerUser);
document.getElementById("loginBtn")?.addEventListener("click", loginUser);
document.getElementById("guestBtn")?.addEventListener("click", loginGuest);
document.getElementById("logoutBtn")?.addEventListener("click", logoutUser);


function isAdminDisplayName(name){
  if (!name) return false;
  const n = name.toLowerCase();
  return n === "mysteryman" || n.includes("admin");
}

// ============================================================================
// 🔧 Admin Tools Visibility (MysteryMan & Admins)
// ============================================================================
onAuthStateChanged(auth, async (user) => {
  const name = user?.displayName?.toLowerCase() || "";
  const roleSnap = user ? await get(ref(db, `users/${user.uid}/role`)) : null;
  const role = roleSnap?.val?.() || "";

  const isOwner = name === "mysteryman";
  const isAdmin = isOwner || role === "admin";

  const systemBtn        = document.getElementById("systemBtn");
  const showBannedBtn    = document.getElementById("showBannedBtn");
  const showMutedBtn     = document.getElementById("showMutedBtn");
  const clearChatBtn     = document.getElementById("clearChatBtn");
  const clearGuestsBtn   = document.getElementById("clearGuestsBtn");
  const userManagerBtn   = document.getElementById("userManagerBtn"); // ➕ NEW


  // === Owner (MysteryMan) βλέπει ΟΛΑ ===
  if (isOwner) {
    systemBtn?.classList.remove("hidden");
    showBannedBtn?.classList.remove("hidden");
    showMutedBtn?.classList.remove("hidden");
    clearChatBtn?.classList.remove("hidden");
    clearGuestsBtn?.classList.remove("hidden");
    userManagerBtn?.classList.remove("hidden"); // ➕ NEW

    return;
  }

  // === Admins βλέπουν όλα εκτός από System ===
  if (isAdmin) {
    showBannedBtn?.classList.remove("hidden");
    showMutedBtn?.classList.remove("hidden");
    clearChatBtn?.classList.remove("hidden");
    clearGuestsBtn?.classList.remove("hidden");
    systemBtn?.classList.add("hidden");
    userManagerBtn?.classList.remove("hidden"); // ➕ NEW

    return;
  }

  // === Άλλοι χρήστες: κρύψε όλα ===
  [userManagerBtn, systemBtn, showBannedBtn, showMutedBtn, clearChatBtn, clearGuestsBtn]
  .forEach(el => el?.classList.add("hidden"));

});
// ============================================================================
// 🧩 User Manager — Part 1: Modal Skeleton (open/close + tabs)
// ============================================================================
const userManagerBtn = document.getElementById("userManagerBtn");
const userManagerModal = document.getElementById("userManagerModal");
const closeUserManagerBtn = document.getElementById("closeUserManagerBtn");

// Άνοιγμα
userManagerBtn?.addEventListener("click", () => {
  userManagerModal?.classList.remove("hidden");
  document.body.classList.add("modal-open"); // κλειδώνει body scroll
});

// Κλείσιμο (Χ)
closeUserManagerBtn?.addEventListener("click", () => {
  userManagerModal?.classList.add("hidden");
  document.body.classList.remove("modal-open");
});

// Κλείσιμο με click εκτός
userManagerModal?.addEventListener("click", (e) => {
  if (e.target === userManagerModal) {
    userManagerModal.classList.add("hidden");
    setTimeout(() => userManagerModal.classList.add("fade-in"), 10);

    document.body.classList.remove("modal-open");
  }
});

// Tabs
document.querySelector(".um-tabs")?.addEventListener("click", (e) => {
  const btn = e.target.closest(".um-tab-btn");
  if (!btn) return;

  // active state στα κουμπιά
  document.querySelectorAll(".um-tab-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");

  // εμφάνιση σωστού pane
  const tab = btn.dataset.tab; // all | admins | vips | guests | banned
  const map = {
  all: "umAll",
  admins: "umAdmins",
  vips: "umVips",
  guests: "umGuests",
  banned: "umBanned",
  muted: "umMuted" // ✅ ΝΕΟ
};

  document.querySelectorAll(".um-pane").forEach(p => p.classList.remove("active"));
  document.getElementById(map[tab])?.classList.add("active");
});
// ============================================================================
// 🧩 User Manager — Part 2: Firebase Wiring + UI Render
// ============================================================================

// === DOM Elements ===
const umPanes = {
  all: document.getElementById("umAll"),
  admins: document.getElementById("umAdmins"),
  vips: document.getElementById("umVips"),
  guests: document.getElementById("umGuests"),
  banned: document.getElementById("umBanned"),
    muted: document.getElementById("umMuted"),

};

// === Helper: Δημιουργία ενός user row ===
// === Δημιουργία γραμμής χρήστη με Unban button ===
function createUserRow(user) {
  const div = document.createElement("div");
  div.className = "um-user-row";

  let extraBtn = "";
  if (user.banned) {
    extraBtn = `<button class="unban-btn" data-uid="${user.uid}" title="Unban χρήστη">↩️ Unban</button>`;
  }
  if (!user.banned && !user.muted) {
  extraBtn += `<button class="mute-btn" data-uid="${user.uid}" title="Mute χρήστη">🔇 Mute</button>`;
}

if (user.muted) {
  extraBtn += `<button class="unmute-btn" data-uid="${user.uid}" title="Unmute χρήστη">🔈 Unmute</button>`;
}

  div.innerHTML = `
    <span class="um-user-name">${user.displayName || "Unknown"}</span>
    <span class="um-user-role">${user.role || "user"}</span>
    <span class="um-user-status ${user.online ? "online" : "offline"}">
      ${user.online ? "🟢 Online" : "⚫ Offline"}
    </span>
    ${extraBtn}
  `;
  return div;
}



// === Φόρτωση όλων των χρηστών (με live status από /status) ===
const usersRef = ref(db, "users");
const statusRef = ref(db, "status");

async function loadUsersWithStatus() {
  const [usersSnap, statusSnap] = await Promise.all([get(usersRef), get(statusRef)]);
  const statusData = statusSnap.val() || {};
  const allUsers = [];

  usersSnap.forEach((child) => {
    const data = child.val();
    const uid = child.key;

    // Βρες status record ακριβώς με ίδιο UID
    const userStatus = statusData[uid];

    let online = false;
    if (userStatus && userStatus.state === "online") {
      online = true;
    }

    allUsers.push({ uid, ...data, online });
  });

  renderUserManager(allUsers);
}


// === Realtime refresh όταν αλλάζει users ή status ===
onValue(usersRef, loadUsersWithStatus);
onValue(statusRef, loadUsersWithStatus);

// === Απόδοση User Manager (render + search + counters) ===
function renderUserManager(allUsers) {
  const searchInput = document.getElementById("umSearchInput");
  const query = searchInput?.value?.toLowerCase() || "";

  // Καθάρισε όλα τα panes
  Object.values(umPanes).forEach((pane) => (pane.innerHTML = ""));

  // === Φιλτράρισμα με βάση την αναζήτηση ===
  const filtered = allUsers.filter((u) =>
    u.displayName?.toLowerCase().includes(query) ||
    u.role?.toLowerCase().includes(query)
  );

  // === Κατηγορίες ===
  const admins = filtered.filter((u) => u.role === "admin" || u.displayName === "MysteryMan");
  const vips   = filtered.filter((u) => u.role === "vip");
  const guests = filtered.filter((u) => !u.role || u.role === "guest");
  const banned = filtered.filter((u) => u.banned === true);
const muted = filtered.filter((u) => u.muted);

  // === Απόδοση ===
  filtered.forEach((u) => umPanes.all.appendChild(createUserRow(u)));
  admins.forEach((u) => umPanes.admins.appendChild(createUserRow(u)));
  vips.forEach((u) => umPanes.vips.appendChild(createUserRow(u)));
  guests.forEach((u) => umPanes.guests.appendChild(createUserRow(u)));
  banned.forEach((u) => umPanes.banned.appendChild(createUserRow(u)));
muted.forEach((u) => umPanes.muted.appendChild(createUserRow(u))); // ✅ ΝΕΟ

  // === Empty-state check ===
  Object.entries({
    all: filtered,
    admins,
    vips,
    guests,
    banned,
  }).forEach(([key, arr]) => {
    if (arr.length === 0) {
      const div = document.createElement("div");
      div.className = "um-empty";
      div.textContent = "📭 Δεν υπάρχουν χρήστες σε αυτή την κατηγορία";
      umPanes[key].appendChild(div);
    }
  });

  // === Counters ===
  updateTabCounters({
    all: filtered.length,
    admins: admins.length,
    vips: vips.length,
    guests: guests.length,
    banned: banned.length,
      muted: muted.length, // ✅ ΝΕΟ

  });
}

// === Live search (χωρίς Enter) ===
const searchInput = document.getElementById("umSearchInput");
if (searchInput) {
  searchInput.addEventListener("input", () => {
    loadUsersWithStatus(); // Επαναφόρτωση λίστας με βάση το query
  });
}

// === Clear search ===
const clearBtn = document.getElementById("umClearSearchBtn");
if (clearBtn && searchInput) {
  clearBtn.addEventListener("click", () => {
    searchInput.value = "";
    loadUsersWithStatus();
  });
}

// === Trigger re-render όταν αλλάζει η βάση ή το search ===
document.addEventListener("users-refresh", () => {
  get(usersRef).then((snapshot) => {
    const allUsers = [];
    snapshot.forEach((child) => {
      const data = child.val();
      allUsers.push({ uid: child.key, ...data });
    });

    const query = searchInput?.value?.toLowerCase() || "";

    Object.values(umPanes).forEach((pane) => (pane.innerHTML = ""));

    const filtered = allUsers.filter((u) =>
      u.displayName?.toLowerCase().includes(query) ||
      u.role?.toLowerCase().includes(query)
    );

    const admins = filtered.filter((u) => u.role === "admin" || u.displayName === "MysteryMan");
    const vips = filtered.filter((u) => u.role === "vip");
    const guests = filtered.filter((u) => !u.role || u.role === "guest");
    const banned = filtered.filter((u) => u.banned === true);

    filtered.forEach((u) => umPanes.all.appendChild(createUserRow(u)));
    admins.forEach((u) => umPanes.admins.appendChild(createUserRow(u)));
    vips.forEach((u) => umPanes.vips.appendChild(createUserRow(u)));
    guests.forEach((u) => umPanes.guests.appendChild(createUserRow(u)));
    banned.forEach((u) => umPanes.banned.appendChild(createUserRow(u)));

    updateTabCounters({
      all: filtered.length,
      admins: admins.length,
      vips: vips.length,
      guests: guests.length,
      banned: banned.length,
    });
  });
});


// === Update tab counters ===
function updateTabCounters(counts) {
  document.querySelectorAll(".um-tab-btn").forEach((btn) => {
    const tab = btn.dataset.tab;
    const num = counts[tab] ?? 0;
    let span = btn.querySelector("span");
    if (!span) {
      span = document.createElement("span");
      btn.appendChild(span);
    }
    span.textContent = `(${num})`;
  });
}
// ============================================================================
// 🧠 User Manager — Quick Tools Actions (Step 1: Change Role)
// ============================================================================
document.addEventListener("click", async (e) => {
  const btn = e.target.closest(".um-tool");
  if (!btn) return;

  const action = btn.dataset.action;
  const row = btn.closest(".um-user-row");
  if (!action || !row) return;

  const targetUid = row.dataset.uid;
  const targetName = row.querySelector(".um-user-name")?.textContent || "Unknown";

  // === Change Role ===
  if (action === "role") {
    const newRole = await showConvoPrompt(
      `🧠 Εισήγαγε νέο ρόλο για τον χρήστη <b>${targetName}</b> (π.χ. admin, vip, user):`
    );

    if (!newRole || newRole === "cancel") return;

    try {
      await update(ref(db, `users/${targetUid}`), { role: newRole.toLowerCase().trim() });

      await push(ref(db, "adminLogs"), {
        type: "role-change",
        targetUid,
        targetName,
        newRole,
        adminUid: auth.currentUser.uid,
        adminName: auth.currentUser.displayName || "Admin",
        createdAt: serverTimestamp(),
      });

      showConvoAlert(`✅ Ο ρόλος του ${targetName} έγινε <b>${newRole}</b>!`);

      // ⚡ Ανανεώνει τη λίστα
      loadUsersWithStatus();
    } catch (err) {
      console.error("Change role error:", err);
      showConvoAlert("❌ Σφάλμα αλλαγής ρόλου: " + err.message);
    }
  }
});
// === Mute button inside User Manager row ===
document.addEventListener("click", async (e) => {
  const btn = e.target.closest(".mute-btn");
  if (!btn) return;

  const targetUid = btn.dataset.uid;
  const userRow = btn.closest(".um-user-row");
  const userName = userRow?.querySelector(".um-user-name")?.textContent || "Unknown";
  const userRole = userRow?.querySelector(".um-user-role")?.textContent || "user";

  await muteUser(targetUid, userName, userRole);
});


// ============================================================================
// 🔇 Mute User Function — (Convo Style Confirm)
// ============================================================================
async function muteUser(targetUid, targetName, currentRole) {
  // === Προστασία MysteryMan & Admin ===
  const isSelfAdmin = auth.currentUser?.displayName === "MysteryMan";
  if (targetName === "MysteryMan") {
    showConvoAlert("⛔ Δεν μπορείς να κάνεις mute τον MysteryMan!");
    return;
  }
  if (currentRole === "admin" && !isSelfAdmin) {
    showConvoAlert("⚠️ Μόνο ο MysteryMan μπορεί να κάνει mute admin!");
    return;
  }

  // === Custom confirm modal ===
  const overlay = document.getElementById("convoBubbleOverlay");
  const content = document.getElementById("bubbleContent");
  const closeBtn = document.getElementById("bubbleCloseBtn");
  const okBtn = document.getElementById("bubbleOkBtn");
  if (!overlay || !content) return;

  content.innerHTML = `
    <div style="margin-bottom:10px;">🔇 Θες σίγουρα να κάνεις MUTE τον χρήστη <strong>${targetName}</strong>;</div>
    <div style="display:flex;justify-content:center;gap:12px;">
      <button id="muteConfirmBtn" class="btn small danger">✅ Ναι</button>
      <button id="muteCancelBtn" class="btn small ghost">❌ Όχι</button>
    </div>
  `;
  overlay.classList.remove("hidden");

  return new Promise((resolve) => {
    const confirmBtn = document.getElementById("muteConfirmBtn");
    const cancelBtn = document.getElementById("muteCancelBtn");

    function close(val) {
      overlay.classList.add("hidden");
      confirmBtn.removeEventListener("click", yes);
      cancelBtn.removeEventListener("click", no);
      closeBtn?.removeEventListener("click", no);
      okBtn?.removeEventListener("click", no);
      resolve(val);
    }

    const yes = () => close(true);
    const no = () => close(false);

    confirmBtn.addEventListener("click", yes);
    cancelBtn.addEventListener("click", no);
    closeBtn?.addEventListener("click", no);
    okBtn?.addEventListener("click", no);
  }).then(async (confirm) => {
    if (!confirm) return;

    await update(ref(db, `users/${targetUid}`), { muted: true });
    await push(ref(db, "adminLogs"), {
      type: "mute",
      targetUid,
      targetName,
      adminUid: auth.currentUser.uid,
      adminName: auth.currentUser.displayName || "Admin",
      createdAt: serverTimestamp(),
    });

    showConvoAlert(`🔇 Ο χρήστης ${targetName} μπήκε σε Mute.`);
    loadUsersWithStatus(); // ανανέωση λίστας
  });
}

// ============================================================================
// 🧩 User Manager — Part 3: Actions Menu (View / Role / Ban)
// ============================================================================
const umContext = document.getElementById("umContextMenu");
let currentUserTarget = null;

// === Right-click on user row ===
document.addEventListener("contextmenu", (e) => {
  const row = e.target.closest(".um-user-row");
  if (!row) return;

  e.preventDefault();
  currentUserTarget = row;

  const { clientX: x, clientY: y } = e;
  umContext.style.left = `${x}px`;
  umContext.style.top = `${y}px`;
  umContext.classList.remove("hidden");
});

// === Click outside to close ===
document.addEventListener("click", (e) => {
  if (!e.target.closest(".um-context")) {
    umContext.classList.add("hidden");
  }
});

// === Handle context menu click ===
umContext.addEventListener("click", async (e) => {
  const action = e.target.dataset.action;
  if (!action || !currentUserTarget) return;

  // ⛔ Κλείσε αμέσως το context menu
  umContext.classList.add("hidden");

  const name = currentUserTarget.querySelector(".um-user-name")?.textContent;
  const role = currentUserTarget.querySelector(".um-user-role")?.textContent;
  const status = currentUserTarget.querySelector(".um-user-status")?.textContent;
  const uid = await findUidByName(name);

   if (action === "view") {
    showProfileModal(name, role, status);
  } else if (action === "role") {
    if (!uid) return showConvoAlert("⚠️ Δεν βρέθηκε UID!");
    await changeUserRole(uid, name, role);
  } else if (action === "mute") {
    if (!uid) return showConvoAlert("⚠️ Δεν βρέθηκε UID!");
    await muteUser(uid, name, role);
  } else if (action === "ban") {
    if (!uid) return showConvoAlert("⚠️ Δεν βρέθηκε UID!");
    await banUser(uid, name, role);
  }
});

// === Helper: Βρες UID από το όνομα (displayName) ===
async function findUidByName(name) {
  try {
    const snap = await get(ref(db, "users"));
    let foundUid = null;
    snap.forEach((child) => {
      const data = child.val();
      if (data.displayName === name) foundUid = child.key;
    });
    return foundUid;
  } catch (err) {
    console.error("findUidByName error:", err);
    return null;
  }
}
// ============================================================================
// 🧩 User Manager — Part 5A : Unban Action
// ============================================================================
// ============================================================================
// 🧩 User Manager — Part 5A : Unban Action (Convo Style Confirm)
// ============================================================================
document.addEventListener("click", async (e) => {
  const btn = e.target.closest(".unban-btn");
  if (!btn) return;

  const targetUid = btn.dataset.uid;
  const userName = btn
    .closest(".um-user-row")
    ?.querySelector(".um-user-name")?.textContent;

  // === Εμφάνιση custom confirm modal ===
  const overlay = document.getElementById("convoBubbleOverlay");
  const content = document.getElementById("bubbleContent");
  const closeBtn = document.getElementById("bubbleCloseBtn");
  const okBtn = document.getElementById("bubbleOkBtn");

  if (!overlay || !content) return;

  content.innerHTML = `
    <div style="margin-bottom:10px;">↩️ Θες σίγουρα να κάνεις UNBAN τον <strong>${userName}</strong>;</div>
    <div style="display:flex;justify-content:center;gap:12px;">
      <button id="unbanConfirmBtn" class="btn small success">✅ Ναι</button>
      <button id="unbanCancelBtn" class="btn small ghost">❌ Όχι</button>
    </div>
  `;
  overlay.classList.remove("hidden");

  return new Promise((resolve) => {
    const confirmBtn = document.getElementById("unbanConfirmBtn");
    const cancelBtn = document.getElementById("unbanCancelBtn");

    function close(val) {
      overlay.classList.add("hidden");
      confirmBtn.removeEventListener("click", yes);
      cancelBtn.removeEventListener("click", no);
      closeBtn?.removeEventListener("click", no);
      okBtn?.removeEventListener("click", no);
      resolve(val);
    }

    const yes = () => close(true);
    const no = () => close(false);

    confirmBtn.addEventListener("click", yes);
    cancelBtn.addEventListener("click", no);
    closeBtn?.addEventListener("click", no);
    okBtn?.addEventListener("click", no);
  }).then(async (confirm) => {
    if (!confirm) return;

    await update(ref(db, `users/${targetUid}`), { banned: false });

    await push(ref(db, "adminLogs"), {
      type: "unban",
      targetUid,
      targetName: userName,
      adminUid: auth.currentUser.uid,
      adminName: auth.currentUser.displayName || "Admin",
      createdAt: serverTimestamp(),
    });

    showConvoAlert(`✅ Ο ${userName} ξε-μπαναρίστηκε επιτυχώς!`);
  });
});

// ============================================================================
// 🧩 User Manager — Part 5B : Unmute Action (Convo Style Confirm)
// ============================================================================
document.addEventListener("click", async (e) => {
  const btn = e.target.closest(".unmute-btn");
  if (!btn) return;

  const targetUid = btn.dataset.uid;
  const userName = btn.closest(".um-user-row")?.querySelector(".um-user-name")?.textContent;

  // === Custom confirm modal ===
  const overlay = document.getElementById("convoBubbleOverlay");
  const content = document.getElementById("bubbleContent");
  const closeBtn = document.getElementById("bubbleCloseBtn");
  const okBtn = document.getElementById("bubbleOkBtn");
  if (!overlay || !content) return;

  content.innerHTML = `
    <div style="margin-bottom:10px;">🔈 Θες σίγουρα να κάνεις UNMUTE τον <strong>${userName}</strong>;</div>
    <div style="display:flex;justify-content:center;gap:12px;">
      <button id="unmuteConfirmBtn" class="btn small success">✅ Ναι</button>
      <button id="unmuteCancelBtn" class="btn small ghost">❌ Όχι</button>
    </div>
  `;
  overlay.classList.remove("hidden");

  return new Promise((resolve) => {
    const confirmBtn = document.getElementById("unmuteConfirmBtn");
    const cancelBtn = document.getElementById("unmuteCancelBtn");

    function close(val) {
      overlay.classList.add("hidden");
      confirmBtn.removeEventListener("click", yes);
      cancelBtn.removeEventListener("click", no);
      closeBtn?.removeEventListener("click", no);
      okBtn?.removeEventListener("click", no);
      resolve(val);
    }

    const yes = () => close(true);
    const no = () => close(false);

    confirmBtn.addEventListener("click", yes);
    cancelBtn.addEventListener("click", no);
    closeBtn?.addEventListener("click", no);
    okBtn?.addEventListener("click", no);
  }).then(async (confirm) => {
    if (!confirm) return;

    await update(ref(db, `users/${targetUid}`), { muted: false });
    await push(ref(db, "adminLogs"), {
      type: "unmute",
      targetUid,
      targetName: userName,
      adminUid: auth.currentUser.uid,
      adminName: auth.currentUser.displayName || "Admin",
      createdAt: serverTimestamp(),
    });

    showConvoAlert(`✅ Ο ${userName} ξε-σιώπησε επιτυχώς!`);
    loadUsersWithStatus(); // ανανέωση λίστας
  });
});



// === Προβολή προφίλ χρήστη (με UID & live status από /status) ===
const profileModal = document.getElementById("umProfileModal");
const closeProfileBtn = document.getElementById("closeProfileBtn");

async function showProfileModal(name, role, status) {
  const nameEl = document.getElementById("profileName");
  const uidEl = document.getElementById("profileUid");
  const roleEl = document.getElementById("profileRole");
  const statusEl = document.getElementById("profileStatus");
  if (!nameEl || !uidEl) return;

  try {
    // 🔍 Βρες το UID από το όνομα
    const usersSnap = await get(ref(db, "users"));
    let target = null;
    usersSnap.forEach((child) => {
      const data = child.val();
      if (data.displayName === name) target = { uid: child.key, ...data };
    });

    const uid = target?.uid || "—";
    nameEl.textContent = name;
    uidEl.textContent = uid;
    roleEl.textContent = role;

    // 🧠 Τσέκαρε πραγματικό status από /status/{uid}
    if (uid && uid !== "—") {
      const statusSnap = await get(ref(db, `status/${uid}/state`));
      const isOnline = statusSnap.exists() && statusSnap.val() === "online";

      statusEl.innerHTML = isOnline
        ? '<span style="color:#10b981">🟢 Online</span>'
        : '<span style="color:#777">⚫ Offline</span>';
    } else {
      statusEl.innerHTML = '<span style="color:#777">⚫ Offline</span>';
    }

    // Εμφάνισε το modal
    profileModal.classList.remove("hidden");
    document.body.classList.add("modal-open");
  } catch (err) {
    console.error("❌ Profile modal error:", err);
    statusEl.innerHTML = '<span style="color:#777">⚫ Offline</span>';
    profileModal.classList.remove("hidden");
    document.body.classList.add("modal-open");
  }
}

closeProfileBtn?.addEventListener("click", () => {
  profileModal.classList.add("hidden");
  document.body.classList.remove("modal-open");
});

profileModal?.addEventListener("click", (e) => {
  if (e.target === profileModal) {
    profileModal.classList.add("hidden");
    document.body.classList.remove("modal-open");
  }
});

// ============================================================================
// 🧩 User Manager — Part 4: Role & Ban Actions (DB + Logs)
// ============================================================================




// === Αλλαγή ρόλου ===
// === Αλλαγή ρόλου (Convo Style Select) ===
async function changeUserRole(targetUid, targetName, currentRole) {
  // === Προστασία MysteryMan ===
  if (targetName === "MysteryMan") {
    showConvoAlert("⛔ Δεν μπορείς να αλλάξεις ρόλο στον MysteryMan!");
    return;
  }

  // === Προστασία admins (μόνο ο MysteryMan μπορεί να τους αλλάξει) ===
  const isSelfAdmin = auth.currentUser?.displayName === "MysteryMan";
  if (currentRole === "admin" && !isSelfAdmin) {
    showConvoAlert("⚠️ Μόνο ο MysteryMan μπορεί να αλλάξει ρόλο admin!");
    return;
  }

  // === Εμφάνιση Convo modal με dropdown επιλογές ===
  const overlay = document.getElementById("convoBubbleOverlay");
  const content = document.getElementById("bubbleContent");
  const closeBtn = document.getElementById("bubbleCloseBtn");
  const okBtn = document.getElementById("bubbleOkBtn");
  if (!overlay || !content) return;

  content.innerHTML = `
    <div style="margin-bottom:10px;">
      🧩 Επίλεξε νέο ρόλο για τον <strong>${targetName}</strong> (τρέχων: ${currentRole})
    </div>
    <select id="roleSelect" style="width:100%;padding:8px;border-radius:8px;background:#0c1218;color:#fff;border:1px solid rgba(255,255,255,.15);">
      <option value="">-- Επίλεξε ρόλο --</option>
      <option value="admin">Admin</option>
      <option value="vip">VIP</option>
      <option value="user">User</option>
      <option value="guest">Guest</option>
    </select>
  `;
  overlay.classList.remove("hidden");

  const roleSelect = document.getElementById("roleSelect");

  return new Promise((resolve) => {
    const cleanup = () => {
      closeBtn?.removeEventListener("click", cancel);
      okBtn?.removeEventListener("click", confirm);
      overlay.removeEventListener("click", outside);
    };

    const confirm = () => {
      const val = roleSelect.value;
      cleanup();
      overlay.classList.add("hidden");
      resolve(val);
    };

    const cancel = () => {
      cleanup();
      overlay.classList.add("hidden");
      resolve(null);
    };

    const outside = (e) => {
      if (e.target === overlay) cancel();
    };

    closeBtn?.addEventListener("click", cancel);
    okBtn?.addEventListener("click", confirm);
    overlay.addEventListener("click", outside);
  }).then(async (newRole) => {
    if (!newRole || newRole === currentRole) return;

    await update(ref(db, `users/${targetUid}`), { role: newRole });

    await push(ref(db, "adminLogs"), {
      type: "roleChange",
      targetUid,
      targetName,
      adminUid: auth.currentUser.uid,
      adminName: auth.currentUser.displayName || "Admin",
      newRole,
      createdAt: serverTimestamp(),
    });

    showConvoAlert(`✅ Ο ρόλος του ${targetName} άλλαξε σε ${newRole}`);
  });
}

// === Ban χρήστη ===
// === Ban χρήστη (Convo Style Confirm) ===
async function banUser(targetUid, targetName, currentRole) {
  // === Προστασία admin / MysteryMan ===
  // Προστασία MysteryMan, αλλά επιτρέπεται μόνο αν είσαι ο ίδιος MysteryMan
const isSelfAdmin = auth.currentUser?.displayName === "MysteryMan";
if (targetName === "MysteryMan") {
  showConvoAlert("⛔ Δεν μπορείς να κάνεις ban τον MysteryMan!");
  return;
}
if (currentRole === "admin" && !isSelfAdmin) {
  showConvoAlert("⚠️ Μόνο ο MysteryMan μπορεί να κάνει ban admin χρήστες!");
  return;
}


  // === Custom confirm modal με κουμπιά ===
  const overlay = document.getElementById("convoBubbleOverlay");
  const content = document.getElementById("bubbleContent");
  const closeBtn = document.getElementById("bubbleCloseBtn");
  const okBtn = document.getElementById("bubbleOkBtn");

  if (!overlay || !content) return;

  content.innerHTML = `
    <div style="margin-bottom:10px;">🚫 Θες σίγουρα να κάνεις ban τον χρήστη <strong>${targetName}</strong>;</div>
    <div style="display:flex;justify-content:center;gap:12px;">
      <button id="banConfirmBtn" class="btn small danger">✅ Ναι</button>
      <button id="banCancelBtn" class="btn small ghost">❌ Όχι</button>
    </div>
  `;

  overlay.classList.remove("hidden");

  return new Promise((resolve) => {
    const confirmBtn = document.getElementById("banConfirmBtn");
    const cancelBtn = document.getElementById("banCancelBtn");

    function close(val) {
      overlay.classList.add("hidden");
      confirmBtn.removeEventListener("click", yes);
      cancelBtn.removeEventListener("click", no);
      closeBtn?.removeEventListener("click", no);
      okBtn?.removeEventListener("click", no);
      resolve(val);
    }

    const yes = () => close(true);
    const no = () => close(false);

    confirmBtn.addEventListener("click", yes);
    cancelBtn.addEventListener("click", no);
    closeBtn?.addEventListener("click", no);
    okBtn?.addEventListener("click", no);
  }).then(async (confirm) => {
    if (!confirm) return;

    await update(ref(db, `users/${targetUid}`), { banned: true });

    await push(ref(db, "adminLogs"), {
      type: "ban",
      targetUid,
      targetName,
      adminUid: auth.currentUser.uid,
      adminName: auth.currentUser.displayName || "Admin",
      createdAt: serverTimestamp(),
    });

    showConvoAlert(`🚫 Ο χρήστης ${targetName} μπήκε στη λίστα banned.`);
  });
}



// ============================================================================
// ADMIN — SYSTEM LOGS (MysteryMan only, UI Base)
// ============================================================================

const systemBtn = document.getElementById("systemBtn");
const systemModal = document.getElementById("systemModal");
const closeSystemBtn = document.getElementById("closeSystemBtn");

onAuthStateChanged(auth, (user) => {
  if (!systemBtn) return;
  if (user && user.displayName?.toLowerCase() === "mysteryman") {
    systemBtn.classList.remove("hidden");
  } else {
    systemBtn.classList.add("hidden");
    systemModal.classList.add("hidden");
  }
});

systemBtn?.addEventListener("click", async () => {
  const logsRef = ref(db, "adminLogs");
  off(logsRef); // 🧹 σταματά τυχόν προηγούμενο listener
  console.log("♻️ Old System Logs listener cleared before new open");

  systemModal.classList.remove("hidden");
  document.body.classList.add("modal-open"); // ✅ κλείδωσε το body

  const logsContainer = document.getElementById("systemLogsList");
  if (!logsContainer) return;

  // 1️⃣ Καθάρισε λίστα και φόρτωσε παλιά logs
  logsContainer.innerHTML = "";
  const snap = await get(logsRef);
  const allLogs = [];
  snap.forEach((child) => allLogs.push(child));
  allLogs.reverse().forEach((child) => renderLogEntry(child));

  // 2️⃣ Ενεργοποίησε Realtime Listener (μόνο όταν ανοίγει το modal)
  initSystemLogsListener(); // ✅ ενεργοποιεί realtime μόλις ανοίξει

  console.log("🧠 System Logs ενεργοποιήθηκαν σε realtime χωρίς F5");
});



// === Create filter buttons (Step 9 Part G) ===
const filterBar = document.getElementById("systemLogsFilter");
if (filterBar && !filterBar.hasChildNodes()) {
  filterBar.innerHTML = `
    <button class="filter-btn active" data-type="all">All</button>
    <button class="filter-btn" data-type="ban">Ban</button>
    <button class="filter-btn" data-type="kick">Kick</button>
    <button class="filter-btn" data-type="delete">Delete</button>
  <button class="filter-btn" data-type="mute">Mute</button>

  `;
}
// === Filtering logic (Step 9 Part G) ===
let currentFilter = "all";
const listEl = document.getElementById("systemLogsList");

filterBar?.addEventListener("click", (e) => {
  if (!e.target.matches(".filter-btn")) return;

  // Αλλαγή ενεργού κουμπιού
  document.querySelectorAll(".filter-btn").forEach((btn) =>
    btn.classList.remove("active")
  );
  e.target.classList.add("active");

  // Ενημέρωση φίλτρου
  currentFilter = e.target.dataset.type;

  // Επανεμφάνιση logs με βάση το φίλτρο
  renderLogs();
});

closeSystemBtn?.addEventListener("click", () => {
  systemModal.classList.add("hidden");
  document.body.classList.remove("modal-open");  // ✅ ξεκλείδωσε το body

  const logsRef = ref(db, "adminLogs");
  off(logsRef); // 🧹 σταματά τον listener
  systemLogsActive = false;
  console.log("🧠 System Logs listener σταμάτησε");
});


// Κλείσιμο με click έξω από το modal
systemModal?.addEventListener("click", (e) => {
  if (e.target === systemModal) {
    systemModal.classList.add("hidden");
    document.body.classList.remove("modal-open"); // ✅ ξεκλείδωσε το body όταν κάνεις click έξω
  }
});

// ============================================================================
// SYSTEM LOGS — Realtime Fetch (Step 2)
// ============================================================================


function renderLogEntry(data) {
  const log = data.val();
  if (!log) return;

  // ⬇️ πάντα φρέσκο reference στο container
  const logsContainer = document.getElementById("systemLogsList");
  if (!logsContainer) return;

  const type = log.type || "other";
  const color =
    type === "ban"   ? "#ff4d4d" :
    type === "kick"  ? "#ffb84d" :
    type === "delete"? "#2d8cff" :
    type === "mute"  ? "#ff66cc" : "#aaa";

  const time = new Date(log.createdAt || Date.now()).toLocaleString("el-GR", {
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });

  const target = log.targetName
    ? `<div style="opacity:0.85;">🎯 target: <strong>${log.targetName}</strong></div>` : "";

  const room = log.room
    ? `<div style="opacity:0.7; font-size:13px;">🏠 room: ${log.room}</div>` : "";

  const el = document.createElement("div");
  el.classList.add("log-item");
  el.dataset.type = type;
  el.innerHTML = `
    <div><strong style="color:${color}">${type.toUpperCase()}</strong> — <span>${log.action || log.type || "unknown"}</span></div>
    ${target}
    <div class="muted">by: ${log.adminName || log.by || "unknown"}</div>
    ${log.reason ? `<div class="muted" style="color:#ffa;">📝 reason: ${log.reason}</div>` : ""}
    ${room}
    <div class="muted small">${time}</div>
  `;

  logsContainer.prepend(el);
  logsContainer.scrollTop = logsContainer.scrollHeight;
}

// ============================================================================
// SYSTEM LOGS — Realtime Listener (Fixed Version)
// ============================================================================

export function initSystemLogsListener() {
  // Αν υπάρχει ήδη listener, καθάρισέ τον πρώτα
  const logsRef = ref(db, "adminLogs");
  off(logsRef); // 🧹 καθάρισε όποιον παλιό listener υπάρχει

  // Ενεργοποίησε νέο listener
  onChildAdded(logsRef, (snap) => renderLogEntry(snap));

  console.log("🧠 Listening to adminLogs (single realtime listener active)");
}

// === Απόδοση logs με βάση το φίλτρο ===
function renderLogs() {
  const allLogs = document.querySelectorAll(".log-item");
  allLogs.forEach((item) => {
    const type = item.dataset.type;
    item.style.display =
      currentFilter === "all" || currentFilter === type ? "" : "none";
  });
}

// === Ξεκίνημα listener μόνο αν είσαι MysteryMan ===
//onAuthStateChanged(auth, (user) => {
  //if (user && user.displayName?.toLowerCase() === "mysteryman") {
    //initSystemLogsListener();
  //}
//});

// ============================================================================
// SYSTEM LOGS — Clear Button (MysteryMan only)
// ============================================================================


const clearLogsBtn = document.getElementById("clearLogsBtn");

clearLogsBtn?.addEventListener("click", async () => {
  const user = auth.currentUser;
  if (!user || user.displayName?.toLowerCase() !== "mysteryman") return;
  await remove(ref(db, "adminLogs"));
  const list = document.getElementById("systemLogsList");
if (list) {
  list.innerHTML = `<p class="muted">📜 Δεν υπάρχουν logs.</p>`;
}

});
// ============================================================================
// ADMIN MENU (Fixed Version)
// ============================================================================
document.addEventListener("DOMContentLoaded", () => {
  const adminMenuBtn = document.getElementById("adminMenuBtn");
  if (!adminMenuBtn) return;

  // === Εμφάνιση κουμπιού μόνο για MysteryMan ===
  onAuthStateChanged(auth, (user) => {
    if (user && user.uid === "LNT3cUi6sUPW3I1FCGSZMJVAymv1") {
      adminMenuBtn.classList.remove("hidden");
    } else {
      adminMenuBtn.classList.add("hidden");
    }
  });
// ============================================================================
// ADMIN — Muted Users Button visibility (Admins only)
// ============================================================================
onAuthStateChanged(auth, (user) => {
  const mutedBtn = document.getElementById("showMutedBtn");
  if (!mutedBtn) return;

  const name = user?.displayName?.toLowerCase() || "";
  const isAdmin = name === "mysteryman" || name.includes("admin");

  if (user && isAdmin) {
    mutedBtn.classList.remove("hidden");
  } else {
    mutedBtn.classList.add("hidden");
  }
});

  // === Άνοιγμα / Κλείσιμο Admin Menu Modal ===
adminMenuBtn.addEventListener("click", () => {
  const existing = document.getElementById("adminMenuModal");
  if (existing) {
    existing.remove();
    return;
  }

  const modal = document.createElement("div");
  modal.id = "adminMenuModal";
  modal.className = "modal-overlay";
  modal.innerHTML = `
    <div class="modal-box">
      <div class="modal-header">
        <strong>🛠️ Admin Menu</strong>
        <button id="closeAdminMenu" class="btn small ghost">✖</button>
      </div>
      <p style="opacity:.7;">(More tools coming soon...)</p>
    </div>
  `;
  document.body.appendChild(modal);

  // === Κλείσιμο modal ===
  document.getElementById("closeAdminMenu")
    ?.addEventListener("click", () => modal.remove());

  // === CLEAR CHAT inside Admin Menu ===
  const menuClearChatBtn = document.getElementById("menuClearChatBtn");
  menuClearChatBtn?.addEventListener("click", () => {
    if (!confirm("⚠️ Clear chat for everyone? This cannot be undone.")) return;
    document.getElementById("clearChatBtn")?.click(); // reuse existing logic
  });

}); // ✅ κλείνει το addEventListener("click", ...)


// === BAN / KICK USER ===
const menuBanUserBtn = document.getElementById("menuBanUserBtn");
if (menuBanUserBtn) {  // ✅ Προστέθηκε έλεγχος ύπαρξης για αποφυγή console error
  menuBanUserBtn.addEventListener("click", async () => {
    const targetUid = await showConvoPrompt("🚫 Enter UID of user to ban:", { placeholder: "User UID..." });
    if (!targetUid) return;

    const confirmBan = await showConvoPrompt(`⚠️ Confirm BAN for UID: ${targetUid}? Type "yes" to proceed:`);
    if (confirmBan?.toLowerCase() !== "yes") return;

    try {
      await update(ref(db, "users/" + targetUid), { banned: true });
      await push(ref(db, "adminLogs"), {
        type: "ban",
        targetUid,
        adminUid: auth.currentUser.uid,
        adminName: auth.currentUser.displayName || "Admin",
        createdAt: serverTimestamp()
      });
      showConvoAlert("✅ User has been banned and logged.");
    } catch (err) {
      console.error("Ban error:", err);
      showConvoAlert("❌ Ban failed — check console.");
    }
  });
} // ✅ τέλος του safety check

}); // ✅ κλείνει το document.addEventListener("DOMContentLoaded")

// ============================================================================
// 🧩 Rooms Panel Toggle
// ============================================================================
const roomsToggleBtn = document.getElementById("roomsToggleBtn");
const roomsPanel = document.getElementById("roomsPanel");

if (roomsToggleBtn && roomsPanel) {
  roomsToggleBtn.classList.remove("hidden"); // δείχνει το κουμπί μετά το login

  roomsToggleBtn.addEventListener("click", () => {
    const visible = roomsPanel.classList.toggle("visible");
    if (visible) {
      console.log("📂 Rooms panel opened");
    } else {
      console.log("📁 Rooms panel closed");
    }
  });
}
// ============================================================================
// 🧩 Convo Bubble Core (Step 1)
// ============================================================================
export function showConvoAlert(message) {
  const overlay = document.getElementById("convoBubbleOverlay");
  const content = document.getElementById("bubbleContent");
  const closeBtn = document.getElementById("bubbleCloseBtn");
  const okBtn = document.getElementById("bubbleOkBtn");

  if (!overlay || !content) return console.warn("⚠️ ConvoBubble missing from DOM");

  content.innerHTML = `<div>${message}</div>`;
  overlay.classList.remove("hidden");

  function closeBubble() {
    overlay.classList.add("hidden");
    document.removeEventListener("keydown", escListener);
    overlay.removeEventListener("click", outsideClick);
    okBtn?.removeEventListener("click", okClick);
    closeBtn?.removeEventListener("click", closeClick);
  }

  const escListener = (e) => { if (e.key === "Escape") closeBubble(); };
  const outsideClick = (e) => { if (e.target === overlay) closeBubble(); };
  const okClick = () => closeBubble();
  const closeClick = () => closeBubble();

  document.addEventListener("keydown", escListener);
  overlay.addEventListener("click", outsideClick);
  okBtn?.addEventListener("click", okClick);
  closeBtn?.addEventListener("click", closeClick);
}

window.showConvoAlert = showConvoAlert; // ✅ Μία φορά μόνο!



// ============================================================================
// 🧩 Convo Bubble — Prompt Mode (Smart Version)
// ============================================================================
// 🧩 Convo Bubble — Prompt Mode (fixed)
export function showConvoPrompt(message, options = {}) {   // <== 🔹 Ανοίγει εδώ
  return new Promise((resolve) => {                        // <== 🔹 Ανοίγει Promise

    const overlay = document.getElementById("convoBubbleOverlay");
    const content  = document.getElementById("bubbleContent");
    const closeBtn = document.getElementById("bubbleCloseBtn");
    const okBtn    = document.getElementById("bubbleOkBtn");
    if (!overlay || !content || !okBtn) return resolve(null);

    // περιεχόμενο + (προαιρετικό) input
const needsInput = true;

    content.innerHTML = needsInput
      ? `<div style="margin-bottom:8px;">${message}</div>
         <input id="bubbleInput" type="text" placeholder="${options.placeholder || ''}"
                style="width:100%;padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:#0c1218;color:#fff;">`
      : `<div>${message}</div>`;

    const input = document.getElementById("bubbleInput") || null;
    overlay.classList.remove("hidden");

    let resolved = false;
    const cleanup = () => {
      document.removeEventListener("keydown", onKey);
      overlay.removeEventListener("click", onOutside);
      closeBtn?.removeEventListener("click", onClose);
      okBtn.removeEventListener("click", onOk);
    };

    const close = (val = null) => {
      if (resolved) return;
      resolved = true;
      overlay.classList.add("hidden");
      cleanup();
      resolve(val);
    };

    const onOk = () => {
      let val = "ok";
      if (input) val = input.value.trim() || "ok";
      close(val);
    };

    const onClose = () => close(null);
    const onOutside = (e) => { if (e.target === overlay) close(null); };
    const onKey = (e) => {
      if (e.key === "Escape") close(null);
      if (e.key === "Enter" && input) {
        e.preventDefault();
        onOk();
      }
    };

    if (input) input.focus(); else okBtn.focus();
    okBtn.addEventListener("click", onOk);
    closeBtn?.addEventListener("click", onClose);
    overlay.addEventListener("click", onOutside);
    document.addEventListener("keydown", onKey);

  });   // <== ✅ Κλείνει το new Promise
}       // <== ✅ Κλείνει τη showConvoPrompt function
// ======================================================
// 🧹 CLEAR GUESTS — Admin Only (MysteryMan)
// ======================================================

const clearGuestsBtn = document.getElementById("clearGuestsBtn");

// === Εμφάνιση κουμπιού μόνο για MysteryMan ===
auth.onAuthStateChanged((user) => {
  if (user && (user.displayName || "").toLowerCase() === "mysteryman") {
    clearGuestsBtn?.classList.remove("hidden");
  } else {
    clearGuestsBtn?.classList.add("hidden");
  }
});

// === Διαγραφή offline Guest χρηστών από /status ===
clearGuestsBtn?.addEventListener("click", async () => {
  const user = auth.currentUser;
  if (!user) return;

  const confirmClear = confirm("🧹 Θες να καθαρίσεις όλους τους OFFLINE guests;");
  if (!confirmClear) return;

  const usersRef = ref(db, "users");
  const snap = await get(usersRef);

  let deletedCount = 0;

  snap.forEach((child) => {
    const val = child.val() || {};
    const uid = child.key;

    const isOffline = !val.state || val.state === "offline";

    const isGuest =
      val.isAnonymous === true ||
      (val.displayName && val.displayName.toLowerCase().startsWith("guest"));

    if (isOffline && isGuest) {
      remove(ref(db, `users/${uid}`));
      remove(ref(db, `status/${uid}`)); // καθάρισε και από status
      deletedCount++;
    }
  });

showConvoAlert(`✅ Καθαρίστηκαν ${deletedCount} offline guests.`);
usersMap.clear();
renderList();

});
// ============================================================================
// 🧩 ADMIN TOOL — Rename User (Step 2 Part 2)
// ============================================================================



const renameUserBtn = document.getElementById("renameUserBtn");
if (renameUserBtn) {
  renameUserBtn.addEventListener("click", async () => {
    const currentUser = auth.currentUser;
    if (!currentUser) return showConvoAlert("⚠️ Δεν είσαι συνδεδεμένος.");
    if (currentUser.displayName !== "MysteryMan") {
      return showConvoAlert("⛔ Μόνο οι admins μπορούν να μετονομάσουν χρήστες.");
    }

    // 1️⃣ Ζήτα UID στόχου
    const targetUid = await showConvoPrompt("🎯 Δώσε το UID του χρήστη που θέλεις να μετονομάσεις:");
    if (!targetUid) return;

    // 2️⃣ Ζήτα νέο nickname
    const newName = await showConvoPrompt("✏️ Γράψε το νέο nickname για αυτόν τον χρήστη:");
    if (!newName || newName.length < 3 || newName.length > 20) {
      return showConvoAlert("⚠️ Το όνομα πρέπει να έχει 3–20 χαρακτήρες.");
    }

    try {
      // === Ενημέρωση DB ===
      await update(ref(db, "users/" + targetUid), { displayName: newName });

      // === Log στο adminLogs ===
      await push(ref(db, "adminLogs"), {
        type: "rename",
        targetUid,
        newName,
        adminUid: currentUser.uid,
        adminName: currentUser.displayName,
        action: "rename",
        createdAt: serverTimestamp(),
      });

      await showConvoAlert(`✅ Ο χρήστης με UID ${targetUid} μετονομάστηκε σε ${newName}.`);
      console.log("🪶 Rename OK:", targetUid, "→", newName);
      // ✅ Force refresh user list (update name immediately)
if (typeof loadUsersWithStatus === "function") loadUsersWithStatus();
// ✅ Refresh right-side users panel too
if (typeof renderUsersList === "function") renderUsersList();

    } catch (err) {
      console.error("❌ Rename error:", err);
      showConvoAlert("❌ Αποτυχία ενημέρωσης: " + err.message);
    }
  });
}
